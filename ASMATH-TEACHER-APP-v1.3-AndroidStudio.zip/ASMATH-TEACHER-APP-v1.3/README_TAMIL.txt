ASMATH TEACHER – ANDROID QUESTION PAPER MAKER
Version 1.3 | Android Studio project

உறுதிப்படுத்தப்பட்ட வினாத்தாள் அமைப்பு

10th Science – 75 மதிப்பெண்கள்
- 1 மதிப்பெண்: 12 வினாக்கள் × 1 = 12
- 2 மதிப்பெண்: 7 வினாக்கள் × 2 = 14
- 4 மதிப்பெண்: 7 வினாக்கள் × 4 = 28
- 7 மதிப்பெண்: 3 வினாக்கள் × 7 = 21 (மூன்றும் கட்டாயம்)

11th / 12th Physics – 70 மதிப்பெண்கள்
- 1 மதிப்பெண்: 15 வினாக்கள் × 1 = 15
- 2 மதிப்பெண்: 9 வினாக்கள்; ஏதேனும் 6 = 12. இதில் 1 கட்டாய Numerical.
- 3 மதிப்பெண்: 9 வினாக்கள்; ஏதேனும் 6 = 18. இதில் 1 கட்டாய Numerical.
- 5 மதிப்பெண்: 10 வினாக்கள்; ஏதேனும் 5 = 25. இப்பகுதியில் கட்டாய Numerical இல்லை.

வசதிகள்
- தமிழ் / ஆங்கில Question Bank
- வகுப்பு, மதிப்பெண், பாடம், difficulty அடிப்படையில் கேள்வி சேமித்தல்
- PDF Textbook upload மற்றும் சாதனத்திலேயே IndexedDB-ல் சேமித்தல்
- PDF-ல் selectable text இருந்தால் PDF.js மூலம் உரை எடுக்கும் வசதி
- கேள்விகளைப் பிரித்து review செய்ய, மதிப்பெண்/பாடம்/compulsory numerical திருத்தி Question Bank-ல் சேர்த்தல்
- Random question paper generation
- Answer key toggle, Print / Save as PDF, saved papers
- JSON Question Bank backup export/import

முக்கிய வரம்புகள்
- PDF வாசிப்பு PDF.js CDN மூலம் நடைபெறுவதால் Internet தேவை.
- Scan செய்யப்பட்ட image-only PDF-களுக்கு OCR இந்தப் பதிப்பில் இல்லை.
- கேள்வி பிரித்தல் மற்றும் மதிப்பெண் கண்டறிதல் heuristic. ஆசிரியர் சரிபார்த்து மட்டுமே Question Bank-ல் சேர்க்க வேண்டும்.
- முழுமையான சரிபார்க்கப்பட்ட textbook question bank முன்கூட்டியே சேர்க்கப்படவில்லை; ஆசிரியர் தமது பாடப்புத்தக PDF-ஐ upload செய்து வினாக்களை ஒப்புதல் அளிக்க வேண்டும்.
- தரவு சாதனத்தின் local storage / IndexedDB-ல் சேமிக்கப்படும். App data அழிக்கப்பட்டால் அல்லது app uninstall செய்தால் backup இல்லாத தரவு இழக்கப்படலாம்.

APK உருவாக்குதல் – GitHub Actions
1. இந்த project-ன் உள்ளடக்கத்தை GitHub repository-யின் main branch root-ல் அதே folder structure-உடன் வைக்கவும்.
2. .github/workflows/build-apk.yml என்ற கோப்பு அந்தத் துல்லியமான பாதையில் இருக்க வேண்டும்.
3. GitHub repository > Actions > Build ASMATH Teacher APK > Run workflow.
4. Workflow வெற்றியடைந்ததும் ASMATH-TEACHER-V1.3-APK artifact-ஐ download செய்யவும்.
5. Artifact ZIP-ஐ extract செய்து app-debug.apk-ஐ Android/Vivo-ல் திறந்து install செய்யவும்.

BUILD STATUS
இந்த source project இங்கு Android SDK / Gradle build environment இல்லாததால் APK ஆக compile செய்யப்படவில்லை. GitHub Actions workflow சேர்க்கப்பட்டுள்ளது; அது வெற்றிகரமாக ஓடிய பிறகே APK கிடைக்கும் என்று உறுதி செய்யலாம். இது debug APK; Play Store release signing அல்ல.
