# ASMATH TEACHER – Question Paper Maker

Tamil Nadu State Board question paper maker for 10th Science and 11th/12th Physics. See `README_TAMIL.txt` for the exact patterns, features, limitations and APK build steps.
